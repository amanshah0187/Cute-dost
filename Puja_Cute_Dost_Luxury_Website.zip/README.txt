PUJA — A little world made by Aman
Open index.html in a browser. Keep the assets folder beside the HTML files.
Pages: Home, Memories, A Letter, Gallery.
To publish online, upload the full folder (not just index.html) to a static hosting service.
